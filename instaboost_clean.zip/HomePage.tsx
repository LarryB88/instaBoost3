
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { useRouter } from "next/router";
import Head from "next/head";

export default function HomePage() {
  const [signupForm, setSignupForm] = useState({ igName: "", email: "" });
  const [testimonialForm, setTestimonialForm] = useState({ igName: "", testimonial: "" });
  const router = useRouter();

  const handleSignupChange = (e) => {
    setSignupForm({ ...signupForm, [e.target.name]: e.target.value });
  };

  const handleTestimonialChange = (e) => {
    setTestimonialForm({ ...testimonialForm, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    router.push("/purchase");
  };

  const handleTestimonialSubmit = (e) => {
    e.preventDefault();
    alert("Thanks for your feedback!");
  };

  return (
    <>
      <Head>
        <title>InstaHero Boost</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="Boost your social presence instantly." />
      </Head>
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-start p-4 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-black opacity-40 z-0" />

        <motion.img
          src="/logo.png"
          alt="Instagram Hero Logo"
          className="w-48 h-48 mt-6 z-10"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.6 }}
        />
        <h1 className="text-4xl font-bold mt-4 text-white drop-shadow z-10">Boost Your Social Power!</h1>
        <p className="text-gray-200 max-w-xl mt-2 z-10">
          Buy real followers and likes for Instagram, TikTok, Twitter, and YouTube. Fast. Easy. Trusted.
        </p>

        <Card className="w-full max-w-md mt-8 shadow-xl z-10">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                placeholder="Username or Handle"
                name="igName"
                value={signupForm.igName}
                onChange={handleSignupChange}
                required
              />
              <Input
                placeholder="Email Address"
                type="email"
                name="email"
                value={signupForm.email}
                onChange={handleSignupChange}
                required
              />
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Get Started</Button>
            </form>
          </CardContent>
        </Card>

        <section className="mt-12 max-w-5xl text-left z-10">
          <h2 className="text-2xl font-bold text-white mb-4">Our Services</h2>
          <ul className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <li className="bg-gradient-to-tr from-purple-500 to-pink-500 text-white p-4 rounded-2xl shadow-lg">
              <h3 className="font-semibold text-lg">Instagram Boost</h3>
              <p>Buy real followers and likes to grow fast on Instagram.</p>
            </li>
            <li className="bg-gradient-to-tr from-blue-400 to-teal-400 text-white p-4 rounded-2xl shadow-lg">
              <h3 className="font-semibold text-lg">TikTok Fame</h3>
              <p>Get TikTok followers, views, and likes to go viral.</p>
            </li>
            <li className="bg-gradient-to-tr from-yellow-400 to-orange-500 text-white p-4 rounded-2xl shadow-lg">
              <h3 className="font-semibold text-lg">Twitter Growth</h3>
              <p>Boost your Twitter presence with real followers and retweets.</p>
            </li>
            <li className="bg-gradient-to-tr from-red-500 to-yellow-400 text-white p-4 rounded-2xl shadow-lg">
              <h3 className="font-semibold text-lg">YouTube Clout</h3>
              <p>Get real subscribers, views, and comments to build your channel.</p>
            </li>
          </ul>
        </section>

        <section className="mt-16 max-w-3xl w-full z-10">
          <h2 className="text-2xl font-bold text-white mb-4">Payments</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white text-black p-4 rounded-2xl shadow-md">
              <img src="/paypal.png" alt="PayPal" className="h-10 mb-2" />
              <h3 className="font-semibold text-lg">PayPal</h3>
              <p>Send your payment securely through PayPal.</p>
              <a
                href="https://www.paypal.me/AiInstaboost"
                target="_blank"
                className="text-blue-600 underline"
                rel="noopener noreferrer"
              >
                paypal.me/AiInstaboost
              </a>
            </div>
            <div className="bg-white text-black p-4 rounded-2xl shadow-md">
              <img src="/bitcoin.png" alt="Bitcoin" className="h-10 mb-2" />
              <h3 className="font-semibold text-lg">Bitcoin</h3>
              <p>Send Bitcoin to the address below:</p>
              <code className="block mt-2 text-sm break-all">39TDaAJMQusek56tK2naLaDGwqbqFDTXpT</code>
            </div>
          </div>
          <p className="text-sm text-gray-300 mt-4">
            After payment, send a screenshot and your username to our email or IG DMs.
          </p>
        </section>

        <section className="mt-16 max-w-xl w-full z-10">
          <h2 className="text-2xl font-bold text-white mb-4">Leave a Testimonial</h2>
          <Card className="shadow-md">
            <CardContent className="p-6">
              <form onSubmit={handleTestimonialSubmit} className="space-y-4">
                <Input
                  placeholder="Your Name or @Handle"
                  name="igName"
                  value={testimonialForm.igName}
                  onChange={handleTestimonialChange}
                />
                <Input
                  placeholder="Your Testimonial"
                  name="testimonial"
                  value={testimonialForm.testimonial}
                  onChange={handleTestimonialChange}
                />
                <Button className="w-full bg-green-600 hover:bg-green-700">Submit Testimonial</Button>
              </form>
            </CardContent>
          </Card>
        </section>

        <footer className="mt-16 text-gray-400 text-sm z-10">
          &copy; 2025 InstaHero Boost. All rights reserved.
        </footer>
      </div>
    </>
  );
}
